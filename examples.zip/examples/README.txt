In this directory you will find a collection of examples on how to use REDCRAFT with some experimental RDC data.

Most subdirectories include a specific README explaining the conditions of the configuration file.

It is important to note that REDCRAFT's results may vary between the 32bit and 64bit compilation.
This is due to the computational precision that is available.
The divergence of results is especially noticable in cases with low data quantity.

For request of features, support, or general feedback please find the contact information at:

http://ifestos.cse.sc.edu/redcraft
