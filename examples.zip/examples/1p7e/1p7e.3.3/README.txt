This structure determination is split into two fragments.
subdirectory frag1 contains the first fragment of 1p7e: section 1 through 20 (residues 3 through 22)
The first two residues were cut off due to lack of usable data.
There is a big data gap past residue 20, so we can only rely on results up to that during a continuous run.
