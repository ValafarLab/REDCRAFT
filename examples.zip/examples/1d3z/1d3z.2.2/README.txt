This directory contains 3 fragments of the run.

Run stage2 with 3 separate configuration files:

stage2 -c redcraft.1-7.conf
stage2 -c redcraft.10-33.conf
stage2 -c redcraft.37-68.conf


The correlation of the backbone may be obtained through:

CalcBBRMSD.prl 2 7 1d3z-ref.pdb
CalcBBRMSD.prl 11 33 1d3z-ref.pdb
CalcBBRMSD.prl 38 68 1d3z-ref.pdb

