After running stage2 you may run the following command to receive backbone comparison:

CalcBBRMSD.prl 2 69 1d3z.pdb

CalcBBRMSD uses `pymol` to compute backbone rmsd.
Due to high quality of RDC data, the entire run has a very shallow depth
of 200.

During the initial run up to residue 36 the determination is robust (RDC RMSD hovering 1Hz)
After which it jumps above 1 and continues growing. For this reason Decimation was enabled
for residues 34-37.

A minimization hook has been added ([Refinement] block in the configuration file).
This minimization utilizes Levenberg-Marquardt technique to relax the 10-degree
rotamer restriction. Execptions are added inside of the minimize.prl file to skip
minimization when there is a RDC data gap. Minimizing a structure without data can 
lead to overminimization and produce low RDC RMSD with high BB RMSD.
