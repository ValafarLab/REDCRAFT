This is the second fragment for 1brf.

Run: stage2 --config=frag2.conf

After running stage2 you may run the following command to receive backbone comparison:

CalcBBRMSD.prl 25 49 1brf.pdb

After observing a default run a minimization routine is added as a refinement hook.
This decision is made when observing a robust determination (rdc score hovers around the same value)
