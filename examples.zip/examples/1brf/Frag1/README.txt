Run: stage2 --config=frag1.conf

After running stage2 you may run the following command to receive backbone comparison:

CalcBBRMSD.prl 2 49 1brf.pdb

CalcBBRMSD uses `pymol` to compute backbone rmsd.
During a regular run up to residue 21 the determination is robust (RDC RMSD hovering 2Hz)
After which it jumps above 2.5.

Standard approaches for handing score jump did not resolve this, and therefore, this run
was split into two fragments. 

1) 1 - 20
2) 24 - 49

Residues 21-23 were skipped because data on 21 causes a spike, and residue 23 is missing data.
