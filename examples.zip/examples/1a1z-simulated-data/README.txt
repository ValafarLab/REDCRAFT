Separate directories, titled 1hz - 4hz contain RDC data for 1a1z simulated 
using REDCAT with the respective simulated noise added.

These data are for you to use as a playground, since all side effects of 
experimental NMR are removed. Each RDC file contains all 6 vectors that
can be interpreted by REDCRAFT, thus making folding very straight forward.

For these directories the presumed "stage1" has already been run.
The expected .angles files have already been created.

Running stage2 you should expect to see:
Error: could not find the configuration file redcraft.conf
       rerun with --create-new to create a default config file

After creating redcraft.conf you can modify its contents to your preference.
